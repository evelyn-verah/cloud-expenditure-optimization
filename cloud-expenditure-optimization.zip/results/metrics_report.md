Dummy placeholder for metrics_report.md in results/
